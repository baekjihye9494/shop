package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.BoardService;
import service.IBoardService;
import vo.Board;

@WebServlet("/-----")
public class BoardNiceController extends HttpServlet {
	private IBoardService boardService;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(session.getAttribute("loginMember") == null) { // 로그인 안되 있는 상태면
			response.sendRedirect(request.getContextPath()+ "/login");
			return;
		}
		boardService = new BoardService();
		
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		int nice = Integer.parseInt(request.getParameter("nice"));
		
		System.out.println(boardNo);
		System.out.println(nice);
		
		if(boardService.modifyBoardNice(nice, boardNo) == 0) {
			response.sendRedirect(request.getContextPath() + "/boardOne?boardNo="+boardNo);
		} else {
			response.sendRedirect(request.getContextPath() + "/boardList");
		}
	}
}
