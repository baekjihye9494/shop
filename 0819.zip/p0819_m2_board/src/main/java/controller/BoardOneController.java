package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.BoardService;
import service.IBoardService;
import vo.Board;

@WebServlet("/boardOne")
public class BoardOneController extends HttpServlet {
	private IBoardService boardService;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(session.getAttribute("loginMember") == null) { // 로그인 안되 있는 상태면
			response.sendRedirect(request.getContextPath()+ "/login");
			return;
		}
		
		// 1) 요청 받아 분석
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		int read = Integer.parseInt(request.getParameter("read"));
		
		System.out.println(boardNo);
		System.out.println(read);
		
		// 2) 서비스 레이어를 요청 (메서드 호출) -> Model값 (자료구조) 구하기 위한 행동
		
		// 조회수 증가
		boardService = new BoardService();
		int row = boardService.modifyBoardRead(read, boardNo);
		
		System.out.println(row + " <-- rowCon");
		
		/*
		if(row != 0) {
			// 상세보기
			boardService = new BoardService();
			List<Map<String, Object>> list = boardService.getBoardOne(boardNo);
			request.setAttribute("list", list);
		}
		*/
		
		// 상세보기
		boardService = new BoardService();
		List<Map<String, Object>> list = boardService.getBoardOne(boardNo);
		request.setAttribute("list", list);
		
		System.out.println(list + "<-- list");
		
		// 3) 뷰 포워딩
		request.getRequestDispatcher("/WEB-INF/view/boardOne.jsp").forward(request, response);
	}

}
