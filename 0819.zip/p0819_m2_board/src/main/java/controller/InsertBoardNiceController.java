package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.INiceService;
import service.NiceService;

@WebServlet("/boardNice")
public class InsertBoardNiceController extends HttpServlet {
	private INiceService niceService;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(session.getAttribute("loginMember") == null) { // 로그인 안되 있는 상태면
			response.sendRedirect(request.getContextPath()+ "/login");
			return;
		}
		
		niceService = new NiceService();
		
		String memberId = request.getParameter("memberId");
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		int read = Integer.parseInt(request.getParameter("read"));
		
		System.out.println(memberId + "<-- memberId");
		System.out.println(boardNo + "<-- boardNo");
		System.out.println(read + "<-- read");
		
		if(niceService.addBoardNice(memberId, boardNo) == 0) {
			response.sendRedirect(request.getContextPath() + "/boardOne?boardNo="+boardNo+"&read="+read);
			return;
		}
		
		session.setAttribute(boardNo+"+"+memberId, boardNo+memberId);
		response.sendRedirect(request.getContextPath() + "/boardOne?boardNo="+boardNo+"&read="+read);
	}
}
