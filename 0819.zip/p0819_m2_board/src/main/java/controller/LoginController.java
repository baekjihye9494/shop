package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.IMemberService;
import service.MemberService;
import vo.Member;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	private IMemberService memberService;
    
	// loginForm
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if(session.getAttribute("loginMember") != null) { // 로그인 되어 있는 상태
			response.sendRedirect(request.getContextPath()+ "/index");
			return;
		}
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/loginForm.jsp");
		rd.forward(request, response);
	}
	
	// loginAction
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String memberId = request.getParameter("memberId");
		String memberPw = request.getParameter("memberPw");
		Member paramMember = new Member();
		
		// 파라미터 세팅
		paramMember.setMemberId(memberId);
		paramMember.setMemberPw(memberPw);
		
		// member값 세팅
		this.memberService = new MemberService();
		Member member = memberService.getMemberLogin(paramMember);
		
		if(member == null) {
			System.out.println("실패");
			response.sendRedirect(request.getContextPath()+ "/login");
			return;
		}
		
		System.out.println(member.toString());
		HttpSession session = request.getSession();
		session.setAttribute("loginMember", member);
		response.sendRedirect(request.getContextPath()+ "/index");
		
	}
}