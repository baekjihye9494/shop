package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vo.Board;

public class BoardDao implements IBoardDao {
		
	@Override
	public int updateBoardNice(Connection conn, int nice, int boardNo) throws SQLException {
		int row = 0;
		String sql = "UPDATE board SET board_nice = ? WHERE board_no = ?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, nice);
			stmt.setInt(2, boardNo);
			
			row = stmt.executeUpdate();
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}
		System.out.println(row + " <-- row");
		
		return row;
	}

	@Override
	public int updateBoardRead(Connection conn, int read, int boardNo) throws SQLException {
		int row = 0;
		String sql = "UPDATE board SET board_read = ? WHERE board_no = ?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, read);
			stmt.setInt(2, boardNo);
			
			row = stmt.executeUpdate();
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}
		System.out.println(row + " <-- row");
		
		return row;
	}

	@Override
	public int insertBoard(Connection conn, Board board) throws SQLException {
		int row = 0;
		
		String sql = "INSERT INTO board (board_title, board_writer, board_content, create_date)"
					 + " VALUES (?, ?, ?, now())";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, board.getTitle());
			stmt.setString(2, board.getWriter());
			stmt.setString(3, board.getContent());
			
			row = stmt.executeUpdate();
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}
		System.out.println(row + " <-- row");
		return row;
	}

	@Override
	public List<Map<String, Object>> selectBoardOne(Connection conn, int boardNo) throws SQLException {
		List<Map<String, Object>> list = null;
		
		
		String sql = "SELECT b.board_no boardNo, b.board_title boardTitle, b.board_writer boardWriter"
				+ " ,b.board_content boardContent, b.create_date createDate, b.board_read boardRead"
				+ " ,t.cnt cnt"
				+ " FROM board b LEFT JOIN"
				+ " (SELECT board_no, COUNT(*) cnt FROM nice GROUP BY board_no) t"
				+ " ON b.board_no = t.board_no"
				+ " WHERE b.board_no = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		System.out.println(boardNo + "boardNo");
		
		try {
			list = new ArrayList<Map<String, Object>>();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, boardNo);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				Map<String,Object> map = new HashMap<String, Object>();
				
				map.put("boardNo", rs.getInt("boardNo"));
				map.put("boardTitle", rs.getString("boardTitle"));
				map.put("boardWriter", rs.getString("boardWriter"));
				map.put("boardContent", rs.getString("boardContent"));
				map.put("createDate", rs.getString("createDate"));
				map.put("boardRead", rs.getInt("boardRead"));
				map.put("cnt", rs.getInt("cnt"));
				
				System.out.println(rs.getInt("boardNo") + "boardNo");
				System.out.println(rs.getInt("cnt") + "cnt");
				System.out.println(map.get("boardNo"));
				System.out.println(map.get("boardTitle"));
				System.out.println(map.get("boardRead"));
				System.out.println(map.get("cnt"));
				
				list.add(map);
			}
		} finally {
			if(rs!=null)   {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
		}
	
		return list;
	}


	@Override
	public List<Board> selectBoardListByPage(Connection conn, int rowPerPage, int beginRow) throws SQLException{
		List<Board> list = null;
		Board board = null;
		String sql = "SELECT board_no boardNo, board_title title, board_writer writer,"
				+ " create_date createDate, board_read boardRead, board_nice nice"
				+ " FROM board ORDER BY create_date LIMIT ?, ?";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			list = new ArrayList<Board>();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, beginRow);
			stmt.setInt(2, rowPerPage);
			rs = stmt.executeQuery();
			while(rs.next()) {
				board = new Board();
				
				board.setBoardNo(rs.getInt("boardNo"));
				board.setTitle(rs.getString("title"));
				board.setWriter(rs.getString("writer"));
				board.setCreateDate(rs.getString("createDate"));
				board.setRead(rs.getInt("boardRead"));
				board.setNice(rs.getInt("nice"));
				
				list.add(board);
			}
		} finally {
			if(rs!=null)   {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
		}
	
		return list;
	}

	@Override
	public int selectBoardCnt(Connection conn, int rowPerPage) throws SQLException{
		int totalCount = 0;
		String sql = "SELECT COUNT(*) FROM board";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			if (rs.next()) {
				totalCount = rs.getInt("COUNT(*)");
			}
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}		
		return totalCount;
	}	
}