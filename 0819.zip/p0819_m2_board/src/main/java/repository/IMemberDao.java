package repository;

import java.sql.Connection;
import java.sql.SQLException;

import vo.Member;

public interface IMemberDao {
	
	// 매개값 id, pw
	// 반환값
	Member selectMemberLogin(Connection conn, Member paramMember) throws SQLException;
	String selectIdCheck(Connection conn, String idck) throws SQLException;
	int insertMember(Connection conn, Member member) throws SQLException;
}
