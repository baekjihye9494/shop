package repository;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface INiceDao {
	
	int insertBoardNice(Connection conn, String memberId, int boardNo) throws SQLException;
	// Map<String, Object> selectBoardNice(Connection conn, int boardNo) throws SQLException;
	// List<Map<String, Object>> selectBoardNice(Connection conn, int boardNo) throws SQLException;
}