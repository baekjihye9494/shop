package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import vo.Member;

public class MemberDao implements IMemberDao {
	
	@Override
	public int insertMember(Connection conn, Member member) throws SQLException {
		int row = 0;
		
		String sql = "INSERT INTO member (member_id, member_pw, member_name, create_date)"
					 + " VALUES (?, PASSWORD(?), ?, now())";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, member.getMemberId());
			stmt.setString(2, member.getMemberPw());
			stmt.setString(3, member.getMemberName());
			
			row = stmt.executeUpdate();
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}
		System.out.println(row + " <-- row");
		return row;
	}

	@Override
	public String selectIdCheck(Connection conn, String idck) throws SQLException {
		String id = null;
		
		// null 일 때 사용한가능 아이디
		String sql = "SELECT member_id memberId FROM member WHERE member_id = ?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, idck);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				System.out.print("있음");
				id = rs.getString("memberId");
			}
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}
		
		return id;
	}

	@Override
	public Member selectMemberLogin(Connection conn, Member paramMember) throws SQLException {
		Member member = null;
		String sql = "SELECT member_id memberId, member_name memberName, member_level memberLevel, create_date createDate"
				+ " FROM member WHERE member_id = ? AND member_pw = PASSWORD(?)";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			member = new Member();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, paramMember.getMemberId());
			stmt.setString(2, paramMember.getMemberPw());
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				member.setMemberId(rs.getString("memberId"));
				member.setMemberName(rs.getString("memberName"));
				member.setMemberLevel(rs.getInt("memberLevel"));
				member.setCreateDate(rs.getString("createDate"));
			}
		} finally {
			if(rs!=null)   {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
		}
		System.out.println(member.toString());
		return member;
	}
}
