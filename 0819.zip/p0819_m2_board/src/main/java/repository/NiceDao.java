package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vo.Board;
import vo.Nice;

public class NiceDao implements INiceDao {

	@Override
	public int insertBoardNice(Connection conn, String memberId, int boardNo) throws SQLException {
		int row = 0;
		String sql = "INSERT INTO nice (board_no, member_id, create_date)"
				+ " VALUES (?, ?, now())";
		PreparedStatement stmt = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, boardNo);
			stmt.setString(2, memberId);
			
			row = stmt.executeUpdate();
		} finally {	
			if(stmt != null) {
				stmt.close();
			}
		}
		
		System.out.println(row + " <-- row");		
		return row;
	}
	
	/*
	@Override
	public Map<String, Object> selectBoardNice(Connection conn, int boardNo) throws SQLException {
		List<Map<String, Object>> list = null;
		Map<String, Object> map = null;
		Board board = null;
		
		String sql = "SELECT b.board_no boardNo, b.board_title title, t.cnt cnt"
				+ " FROM board b"
				+ " INNER JOIN"
				+ " (SELECT board_no, COUNT(*) cnt"
				+ " FROM nice"
				+ " GROUP BY board_no) t"
				+ " ON b.board_no = t.board_no"
				+ " WHERE b.board_no = ?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			list = new ArrayList<Map<String, Object>>();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, boardNo);
			
			rs = stmt.executeQuery();
			if(rs.next()) {
				map = new HashMap<String, Object>();
				board = new Board();
				board.setBoardNo(rs.getInt("boardNo"));
				board.setTitle(rs.getString("title"));
				
				map.put("board", board);
				map.put("cnt", rs.getInt("cnt"));
				
				list.add(map);
			}
		} finally {	
			if(stmt != null) {
				stmt.close();
			}
		}
		System.out.println(map.get("board").toString());
		System.out.println(map.get("cnt"));
		return list;
	}
	
	
	@Override
	public List<Map<String, Object>> selectBoardNice(Connection conn, int boardNo) throws SQLException {
		List<Map<String, Object>> list = null;
		Map<String, Object> map = null;
		Board board = null;
		
		String sql = "SELECT b.board_no boardNo, b.board_title title, t.cnt cnt"
				+ " FROM board b"
				+ " INNER JOIN"
				+ " (SELECT board_no, COUNT(*) cnt"
				+ " FROM nice"
				+ " GROUP BY board_no) t"
				+ " ON b.board_no = t.board_no"
				+ " WHERE b.board_no = ?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			list = new ArrayList<Map<String, Object>>();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, boardNo);
			
			rs = stmt.executeQuery();
			if(rs.next()) {
				map = new HashMap<String, Object>();
				board = new Board();
				board.setBoardNo(rs.getInt("boardNo"));
				board.setTitle(rs.getString("title"));
				
				map.put("board", board);
				map.put("cnt", rs.getInt("cnt"));
				
				list.add(map);
			}
		} finally {	
			if(stmt != null) {
				stmt.close();
			}
		}
		System.out.println(map.get("board").toString());
		System.out.println(map.get("cnt"));
		return list;
	}
	*/
}
