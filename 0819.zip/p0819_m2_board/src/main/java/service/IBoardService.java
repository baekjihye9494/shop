package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import vo.Board;

public interface IBoardService {
	
	int modifyBoardNice(int nice, int boardNo);
	int modifyBoardRead(int read, int boardNo);
	int addBoard(Board board);
	List<Map<String, Object>> getBoardOne(int boardNo);
	// return값 : List<Board>, int lastPage
	Map<String, Object> getBoardList(int rowPerPage, int currentPage);
}
