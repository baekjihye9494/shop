package service;

import vo.Member;

public interface IMemberService {
	
	Member getMemberLogin(Member paramMember);
	String getIdCheck(String idck);
	int addMember(Member member);
}
