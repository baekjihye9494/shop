package service;

import java.util.List;
import java.util.Map;

public interface INiceService {
	
	int addBoardNice(String memberId, int boardNo);
	// Map<String, Object> getBoardNice(int boardNo);
	// List<Map<String, Object>> getBoardNice(int boardNo);
}
