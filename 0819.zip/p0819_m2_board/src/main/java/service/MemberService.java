package service;

import java.sql.Connection;
import java.sql.SQLException;

import commons.DBUtil;
import repository.BoardDao;
import repository.IMemberDao;
import repository.MemberDao;
import vo.Member;

public class MemberService implements IMemberService{
	private IMemberDao memberDao;
	
	@Override
	public int addMember(Member member) {
		int result = 0;
		Connection conn = null;
		
		try {
			conn = new DBUtil().getConnection();
			conn.setAutoCommit(false);
			
			memberDao = new MemberDao();
			
			result = memberDao.insertMember(conn, member);
			
			if(result == 0) {
				throw new Exception(); 
			}
				
			conn.commit();		
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public String getIdCheck(String idck) {
		String id = null;		
		Connection conn = null;
		
		try {
			conn = new DBUtil().getConnection();
			memberDao = new MemberDao();
			
			id = memberDao.selectIdCheck(conn, idck);
			
			conn.commit();
		} catch(Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}	
		return id;
	}

	@Override
	public Member getMemberLogin(Member paramMember) {
		Member member = null;
		Connection conn = null;
		
		try {
			conn = new DBUtil().getConnection();
			memberDao = new MemberDao();
			member = new Member();

			// member에 값 담기
			member = memberDao.selectMemberLogin(conn, paramMember);
			
			if(member == null) {
				throw new Exception();
			} 
			
			conn.commit();		
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println(member.toString());
		return member;
	}
	
}
