package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import commons.DBUtil;
import repository.INiceDao;
import repository.NiceDao;
import vo.Nice;

public class NiceService implements INiceService {
	private INiceDao niceDao;
	
	@Override
	public int addBoardNice(String memberId, int boardNo) {
		int result = 0;
		Connection conn = null;
		
		try {
			conn = new DBUtil().getConnection();
			conn.setAutoCommit(false);
			
			niceDao = new NiceDao();
			
			result = niceDao.insertBoardNice(conn, memberId, boardNo);
			
			if(result == 0) {
				throw new Exception(); 
			}
				
			conn.commit();		
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(result + " <-- result");
		return result;
	}
	/*
	@Override
	public List<Map<String, Object>> getBoardNice(int boardNo) {
		Map<String, Object> map = null;
		Connection conn = null;
		List<Map<String, Object>> list = null;
		try {
			conn = new DBUtil().getConnection();
			conn.setAutoCommit(false);
			
			niceDao = new NiceDao();
			
			list = niceDao.selectBoardNice(conn, boardNo);
			
			if(map == null) {
				throw new Exception(); 
			}
				
			conn.commit();		
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return list;
	}
	*/
}
