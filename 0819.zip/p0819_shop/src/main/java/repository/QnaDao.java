package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vo.QnA;

public class QnaDao {
	
	// 문의글 삭제
	public int deleteQna(Connection conn, int qnaNo) throws SQLException {
		int row = 0;
		
		String sql = "DELETE FROM qna WHERE q_no = ?";
		PreparedStatement stmt = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, qnaNo);
			
			row = stmt.executeUpdate();
		} finally {
			if(stmt != null) {
				stmt.close();
			}
		}
		
		return row;
	}
	
	
	
	
	//문의글 수정
		public int updateQna(Connection conn, QnA qna) throws SQLException {
			int row = 0;
			
			String sql = "UPDATE qna SET q_title = ?, q_content = ?, update_date = NOW()"
					+ " WHERE qnaNo = ?";
			PreparedStatement stmt = null;		
			try {
				stmt = conn.prepareStatement(sql);
				stmt.setString(1, qna.getqTitle());
				stmt.setString(2, qna.getqContent());
				stmt.setString(3, qna.getqUpdateDate());
				stmt.setInt(4, qna.getqNo());

				row = stmt.executeUpdate();
			} finally {
				if(stmt != null) {
					stmt.close();
				}
			}
			System.out.println(row + " <-- row");
			return row;
		}
	
	
	
	
	
	// 문의글 추가
		public int insertQna(Connection conn, QnA qna) throws SQLException {
			int row = 0;
			
			String sql = "INSERT INTO qna (q_title, q_content, q_pass, create_date)"
						 + " VALUES (?, ?, PASSWORD(?) now())";
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			try {
				stmt = conn.prepareStatement(sql);
				stmt.setString(1, qna.getqTitle());
				stmt.setString(2, qna.getqContent());
				stmt.setString(3, qna.getqPass());
				stmt.setString(4, qna.getqCreateDate());
				
				
				// 1) insert
				stmt.executeUpdate(); // insert 성공한 row 수
				
				// 2) select last_ai_key from ...
				rs = stmt.getGeneratedKeys(); // select last_key
				
			} finally {
				if(rs != null) {
					rs.close();
				}
				if(stmt != null) {
					stmt.close();
				}
			}
			return row;
		}
		
		//문의글 마지막 리스트 
		public int selectQnaLastPage(Connection conn, int rowPerPage) throws SQLException {
			int totalCount = 0;
			String sql = "SELECT COUNT(*) FROM qna";
			
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			try {
				stmt = conn.prepareStatement(sql);
				rs = stmt.executeQuery();

				if (rs.next()) {
					totalCount = rs.getInt("COUNT(*)");
				}
			} finally {
				if(rs != null) {
					rs.close();
				}
				if(stmt != null) {
					stmt.close();
				}
			}		
			return totalCount;
		}
		
		
		
		// 문의글 리스트
		public List<QnA> selectQnaList(Connection conn , int rowPerPage, int beginRow) throws SQLException {
			
			List<QnA> list = null;
			QnA qna = null;
				
				String sql = "SELECT q_no qNo,  q_title qTitle, create_date qCreateDate FROM qna ORDER BY create_date LIMIT ?, ?";
				PreparedStatement stmt = null;
				ResultSet rs = null;
				
				try {
					list = new ArrayList<QnA>();
					stmt = conn.prepareStatement(sql);
					stmt.setInt(1, beginRow);
					stmt.setInt(2, rowPerPage);
					rs = stmt.executeQuery();
					while(rs.next()) {
						qna = new QnA();
						qna.setqNo(rs.getInt("qNo"));
						qna.setqTitle(rs.getString("qTitle"));
						qna.setqCreateDate(rs.getString("qCreateDate"));
						list.add(qna);
					}
				} finally {
					if(rs!=null)   {
						rs.close();
					}
					if(stmt!=null) {
						stmt.close();
					}
				}
				
				
				return list;
			}
		
}
