package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import repository.QnaDao;
import vo.Notice;
import vo.QnA;


public class QnaService {
	private  QnaDao qnaDao;
	
	//문의글 리스트 
		public List<QnA> getQnaList (int rowPerPage , int currentPage) {
			Connection conn = null;
			List<QnA> list = null; 
					
			try {
				conn = new DBUtil().getConnection();
				conn.setAutoCommit(false); // executeUpdate() 실행 시 자동 커밋을 막음
				
				QnaDao qnaDao = new QnaDao(); 
				
				int beginRow = (currentPage - 1) * rowPerPage;
				
				list = qnaDao.selectQnaList(conn, rowPerPage, beginRow);
				
				if(list == null) { // 쿼리문이 정상적으로 적용되었는지 확인 후 아닐 시 예외처리
					throw new Exception();
				}

				conn.commit();		
			} catch (Exception e) {
				e.printStackTrace(); // console에 예외메세지 출력
				try {
					conn.rollback(); // 예외를 던지지말고 감싸야함
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			return list;
		}
	
	
	
	//문의글 마지막 페이지
		public int getQnaLastPage(int rowPerPage) {
			int lastPage = 0;
			int totalCount = 0;
			Connection conn = null;
			QnaDao qnaDao = null;
			
			try {
				conn = new DBUtil().getConnection();
				conn.setAutoCommit(false); // executeUpdate() 실행 시 자동 커밋을 막음
				
				qnaDao = new QnaDao();		 			
				totalCount = qnaDao.selectQnaLastPage(conn, rowPerPage);
				
				if(totalCount == 0) { // 쿼리문이 정상적으로 적용되었는지 확인 후 아닐 시 예외처리
					throw new Exception();
				}
				
				lastPage = totalCount / rowPerPage;
				if (totalCount % rowPerPage != 0) {
					lastPage += 1;
				}
				conn.commit();		
			} catch (Exception e) {
				e.printStackTrace(); // console에 예외메세지 출력
				try {
					conn.rollback(); // 예외를 던지지말고 감싸야함
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return lastPage;
		}

	// 게시글 추가
	public boolean addQna(QnA qna) {
		boolean result = true;
		Connection conn = null;
		try {
			conn = new DBUtil().getConnection();
			conn.setAutoCommit(false); // executeUpdate() 실행 시 자동 커밋을 막음
			
			QnaDao qnaDao = new QnaDao();
			
			if(qnaDao.insertQna(conn, qna) != 1) { // 쿼리문이 정상적으로 적용되었는지 확인 후 아닐 시 예외처리
				result = false;
				throw new Exception();
			}			
			conn.commit();	
				
			conn.commit();		
		} catch (Exception e) {
			e.printStackTrace(); // console에 예외메세지 출력
			try {
				conn.rollback(); // 예외를 던지지말고 감싸야함
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	
	
	// 게시글 수정
	public int modifyQna(QnA qna) {
		int row = 0;
		
		Connection conn = null;
		try {
			conn = new DBUtil().getConnection();
			conn.setAutoCommit(false); // executeUpdate() 실행 시 자동 커밋을 막음
			
			qnaDao = new QnaDao();
			
			row = qnaDao.updateQna(conn, qna);
			
			if(row != 0) {
				throw new Exception();  // 이미지 입력실패시 강제로 롤백(catch절 이동)
			}
				
			conn.commit();		
		} catch (Exception e) {
			e.printStackTrace(); // console에 예외메세지 출력
			try {
				conn.rollback(); // 예외를 던지지말고 감싸야함
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return row;
	}
	
	// 게시글 삭제	
		public int removeQna(int qnaNo) {
			int result = 0;
			
			Connection conn = null;
			try {
				conn = new DBUtil().getConnection();
				conn.setAutoCommit(false); // executeUpdate() 실행 시 자동 커밋을 막음
				
				qnaDao = new QnaDao();
				
				result = qnaDao.deleteQna(conn, qnaNo);
				if(result != 0) {
					throw new Exception();  // 이미지 입력실패시 강제로 롤백(catch절 이동)
					}
					
				conn.commit();	
				
			} catch (Exception e) {
				e.printStackTrace(); // console에 예외메세지 출력
				try {
					conn.rollback(); // 예외를 던지지말고 감싸야함
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return result;
		}
			
}

