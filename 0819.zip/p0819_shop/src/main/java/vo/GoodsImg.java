package vo;

public class GoodsImg {
	private int goodsImgNo;
	private String fileName;
	private String OriginFileName;
	private String contentType;
	private String createDate;
	public int getGoodsImgNo() {
		return goodsImgNo;
	}
	public void setGoodsImgNo(int goodsImgNo) {
		this.goodsImgNo = goodsImgNo;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getOriginFileName() {
		return OriginFileName;
	}
	public void setOriginFileName(String originFileName) {
		OriginFileName = originFileName;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	
}
