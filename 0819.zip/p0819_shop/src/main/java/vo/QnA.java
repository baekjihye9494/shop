package vo;

public class QnA {
	private int qNo;
	private String customerId;
	private String qTitle;
	private String qContent;
	private String qPass;
	private String qCreateDate;
	private String qUpdateDate;
	
	
	public int getqNo() {
		return qNo;
	}
	public void setqNo(int qNo) {
		this.qNo = qNo;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getqTitle() {
		return qTitle;
	}
	public void setqTitle(String qTitle) {
		this.qTitle = qTitle;
	}
	public String getqContent() {
		return qContent;
	}
	public void setqContent(String qContent) {
		this.qContent = qContent;
	}
	public String getqPass() {
		return qPass;
	}
	public void setqPass(String qPass) {
		this.qPass = qPass;
	}
	public String getqCreateDate() {
		return qCreateDate;
	}
	public void setqCreateDate(String qCreateDate) {
		this.qCreateDate = qCreateDate;
	}
	
	public String getqUpdateDate() {
		return qUpdateDate;
	}
	public void setqUpdateDate(String qUpdateDate) {
		this.qUpdateDate = qUpdateDate;
	}
	
	
	
	
		
}
