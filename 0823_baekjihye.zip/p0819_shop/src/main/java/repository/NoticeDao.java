package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vo.Notice;

public class NoticeDao {
	
	public Notice selectNoticeOne(Connection conn, int noticeNo) throws SQLException {

		Notice notice = null;
		/*
		String sql = "SELECT board_no boardNo, board_title title, board_writer writer,"
				+ " board_content boardContent, create_date createDate, board_read boardRead, board_nice nice"
				+ " FROM board WHERE board_no = ?";
		*/
		
		String sql  = "SELECT notice_no noticeNo, notice_title noticeTitle, "
				+ "notice_content noticeContent, create_date createDate FROM notice WHERE notice_no = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		System.out.println(noticeNo + "noticeNo");
		
		try {

			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, noticeNo);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				notice = new Notice();		
				notice.setNoticeNo(rs.getInt("noticeNo"));
				notice.setNoticeTitle(rs.getString("noticeTitle"));
				notice.setNoticeContent(rs.getString("noticeContent"));
				notice.setCreateDate(rs.getString("createDate"));
			}
		} finally {
			if(rs!=null)   {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
		}		
	
		return notice;
	}	
		
	
	//게시긁리스트 마지막페이지
	public int selectNoticeLastPage(Connection conn, int rowPerPage) throws SQLException {
		int totalCount = 0;
		String sql = "SELECT COUNT(*) FROM notice";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			if (rs.next()) {
				totalCount = rs.getInt("COUNT(*)");
			}
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(stmt != null) {
				stmt.close();
			}
		}		
		return totalCount;
	}
	
	// 사원 리스트
	public List<Notice> selectNoticeList(Connection conn, int rowPerPage, int beginRow) throws SQLException {
		List<Notice> list = null;
		Notice notice = null;
		
		String sql = "SELECT notice_no noticeNo, notice_title noticeTitle, create_date createDate FROM notice ORDER BY create_date LIMIT ?, ?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			list = new ArrayList<Notice>();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, beginRow);
			stmt.setInt(2, rowPerPage);
			rs = stmt.executeQuery();
			while(rs.next()) {
				notice = new Notice();
				notice.setNoticeNo(rs.getInt("noticeNo"));
				notice.setNoticeTitle(rs.getString("noticeTitle"));
				notice.setCreateDate(rs.getString("createDate"));
	
				list.add(notice);
			}
		} finally {
			if(rs!=null)   {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
		}
		
		
		return list;
	}
}