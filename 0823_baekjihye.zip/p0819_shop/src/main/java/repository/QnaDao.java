package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vo.Qna;

public class QnaDao {
	
	// 문의글 삭제
	public int deleteQna(Connection conn, Qna qna) throws SQLException {
		int row = 0;
		
		String sql = "DELETE FROM qna WHERE q_no = ? and q_pass =?  ";
		PreparedStatement stmt = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, qna.getQnaNo());
			stmt.setString(2, qna.getQnaPass());
			row = stmt.executeUpdate();
		} finally {
			if(stmt != null) {
				stmt.close();
			}
		}
		
		return row;
	}
	
	
	
	
	//문의글 수정
		public int updateQna(Connection conn, Qna qna) throws SQLException {
			int row = 0;
			
			String sql = "UPDATE qna SET q_title qnaTitle = ?, q_content qnaContent = ?, update_date updateDate = NOW()"
					+ " WHERE q_no = ? and q_pass =?";
			PreparedStatement stmt = null;		
			try {
				stmt = conn.prepareStatement(sql);
				stmt.setString(1, qna.getQnaTitle());
				stmt.setString(2, qna.getQnaContent());
				stmt.setString(3, qna.getUpdateDate());
				stmt.setInt(4, qna.getQnaNo());
				stmt.setString(5, qna.getQnaPass());

				row = stmt.executeUpdate();
			} finally {
				if(stmt != null) {
					stmt.close();
				}
			}
			System.out.println(row + " <-- row");
			return row;
		}
	
	
	
	
	
	// 문의글 추가
		public int insertQna(Connection conn, Qna qna) throws SQLException {
			int row = 0;
			
			String sql = "INSERT INTO qna (q_title qnaTitle, q_content qnaContent, q_pass qnaPass, create_date createDate) VALUES (?, ?, PASSWORD(?), now())";
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			try {
				stmt = conn.prepareStatement(sql);
				stmt.setString(1, qna.getQnaTitle());
				stmt.setString(2, qna.getQnaContent());
				stmt.setString(3, qna.getQnaPass());
				stmt.setString(4, qna.getCreateDate());
				
				
				// 1) insert
				row = stmt.executeUpdate(); // insert 성공한 row 수
				
				
			} finally {
				if(rs != null) {
					rs.close();
				}
				if(stmt != null) {
					stmt.close();
				}
			}
			return row;
		}
		
		//문의글 마지막 리스트 
		public int selectQnaLastPage(Connection conn, int rowPerPage) throws SQLException {
			int totalCount = 0;
			String sql = "SELECT COUNT(*) FROM qna";
			
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			try {
				stmt = conn.prepareStatement(sql);
				rs = stmt.executeQuery();

				if (rs.next()) {
					totalCount = rs.getInt("COUNT(*)");
				}
			} finally {
				if(rs != null) {
					rs.close();
				}
				if(stmt != null) {
					stmt.close();
				}
			}		
			return totalCount;
		}
		
		
		
		// 문의글 리스트
		public List<Qna> selectQnaList(Connection conn , int rowPerPage, int beginRow) throws SQLException {
			
			List<Qna> list = null;
			Qna qna = null;
				
			String sql = "SELECT q_no qnaNo,  q_title qnaTitle, create_date createDate FROM qna ORDER BY create_date LIMIT ?, ?";
			PreparedStatement stmt = null;
			ResultSet rs = null;
			
			try {
				list = new ArrayList<Qna>();
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, beginRow);
				stmt.setInt(2, rowPerPage);
				rs = stmt.executeQuery();
				while(rs.next()) {
					qna = new Qna();
					qna.setQnaNo(rs.getInt("qnaNo"));
					qna.setQnaTitle(rs.getString("qnaTitle"));
					qna.setCreateDate(rs.getString("createDate"));
					
					list.add(qna);
				}
			} finally {
				if(rs!=null)   {
					rs.close();
				}
				if(stmt!=null) {
					stmt.close();
				}
			}
			
			
			return list;
		}
		
}
