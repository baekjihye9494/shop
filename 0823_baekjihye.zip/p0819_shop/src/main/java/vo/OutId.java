/*
 * package vo;
 * 
 * public class OutId {
 * 
 * 
 * }
 */
